import streamlit as st
from cryptography.hazmat.primitives.asymmetric import rsa, ec, padding
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding as sym_padding
import os
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

# Streamlit Title
st.title("Encryption/Decryption App")

# Sidebar with Algorithm Information
st.sidebar.title("Algorithm Information")

algorithm_info = {
    "RSA": """
        **RSA (Rivest-Shamir-Adleman) Encryption**
        
        **History**: Developed in 1977 by Ron Rivest, Adi Shamir, and Leonard Adleman.
        
        **Mathematical Foundation**:
        1. Choose two large prime numbers: p and q.
        2. Compute n = p × q (modulus).
        3. Compute Euler’s totient function: φ(n) = (p - 1)(q - 1).
        4. Select an encryption exponent e such that 1 < e < φ(n) and gcd(e, φ(n)) = 1.
        5. Compute the private key d such that d ≡ e^(-1) (mod φ(n)).
        
        **Pros**:
        - High security for large key sizes
        - Widely used and trusted
        
        **Cons**:
        - Slow for large data encryption
        - Large key sizes needed for strong security
    """,
    "ECC": """
        **Elliptic Curve Cryptography (ECC)**
        
        **History**: Introduced in 1985 by Neal Koblitz and Victor Miller as an alternative to RSA.
        
        **Mathematical Foundation**:
        - Based on the equation: y² ≡ x³ + ax + b (mod p)
        - Key generation uses elliptic curve point multiplication.
        - Encryption typically uses ECDH for shared secret generation.
        
        **Pros**:
        - Strong security with smaller key sizes compared to RSA
        - Efficient for mobile and low-power devices
        
        **Cons**:
        - More complex implementation
        - Limited support in legacy systems
    """,
    "AES": """
        **Advanced Encryption Standard (AES)**
        
        **History**: Developed by Belgian cryptographers Vincent Rijmen and Joan Daemen in 2001.
        
        **Mathematical Foundation**:
        - Operates on fixed-size blocks of data (128-bits).
        - Uses substitution-permutation networks and rounds of encryption.
        
        **Pros**:
        - Fast and efficient for data encryption
        - Widely adopted for secure communication
        
        **Cons**:
        - Requires secure key management
        - Limited by block size (128 bits)
    """,
    "Blowfish": """
        **Blowfish Cipher**
        
        **History**: Designed in 1993 by Bruce Schneier as a fast and secure block cipher.
        
        **Mathematical Foundation**:
        - Operates on a 16-round Feistel network.
        - Key expansion generates 18 subkeys and four S-boxes.
        
        **Pros**:
        - Fast encryption with a flexible key length (32–448 bits)
        - Good performance on low-power devices
        
        **Cons**:
        - Outdated for modern security needs
        - Considered less secure than AES for long-term use
    """
}

for algo, description in algorithm_info.items():
    with st.sidebar.expander(algo):
        st.markdown(description)

# Persist keys across sessions
if "rsa_private_key" not in st.session_state:
    st.session_state.rsa_private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    st.session_state.rsa_public_key = st.session_state.rsa_private_key.public_key()

if "ecc_private_key" not in st.session_state:
    st.session_state.ecc_private_key = ec.generate_private_key(ec.SECP256R1())
    st.session_state.ecc_public_key = st.session_state.ecc_private_key.public_key()

if "aes_key" not in st.session_state:
    st.session_state.aes_key = os.urandom(32)  # Fixed AES key

if "blowfish_key" not in st.session_state:
    st.session_state.blowfish_key = os.urandom(16)  # Fixed Blowfish key

# Define Encryption Classes
class RSAEncryption:
    @staticmethod
    def encrypt(plaintext: str) -> str:
        encrypted = st.session_state.rsa_public_key.encrypt(
            plaintext.encode(),
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        return encrypted.hex()

    @staticmethod
    def decrypt(encrypted_text: str) -> str:
        decrypted = st.session_state.rsa_private_key.decrypt(
            bytes.fromhex(encrypted_text),
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        return decrypted.decode()

class ECCEncryption:
    @staticmethod
    def encrypt(plaintext: str) -> str:
        # Generate the shared key from the ECC keys using ECDH
        shared_key = st.session_state.ecc_private_key.exchange(ec.ECDH(), st.session_state.ecc_public_key)
        
        # Derive the AES key from the shared secret using PBKDF2
        derived_key = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=b'salt',  # Use a fixed salt for simplicity, can be more complex
            iterations=100000,
            backend=default_backend()
        ).derive(shared_key)
        
        # Generate a random 12-byte IV for AES GCM mode
        iv = os.urandom(12)
        
        # Set up AES encryption in GCM mode
        cipher = Cipher(algorithms.AES(derived_key), modes.GCM(iv), backend=default_backend())
        encryptor = cipher.encryptor()
        
        # Encrypt the plaintext
        encrypted = encryptor.update(plaintext.encode()) + encryptor.finalize()
        
        # Return the concatenated IV + ciphertext + tag as a hexadecimal string
        return iv.hex() + encrypted.hex() + encryptor.tag.hex()

    @staticmethod
    def decrypt(encrypted_text: str) -> str:
        # Extract the IV, ciphertext, and tag from the encrypted text
        iv = bytes.fromhex(encrypted_text[:24])  # 12 bytes IV
        tag = bytes.fromhex(encrypted_text[-32:])  # 16 bytes tag
        encrypted_data = bytes.fromhex(encrypted_text[24:-32])  # The actual encrypted data
        
        # Derive the AES key from the shared secret using PBKDF2
        shared_key = st.session_state.ecc_private_key.exchange(ec.ECDH(), st.session_state.ecc_public_key)
        derived_key = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=b'salt',  # Use a fixed salt for simplicity, can be more complex
            iterations=100000,
            backend=default_backend()
        ).derive(shared_key)
        
        # Set up AES decryption in GCM mode
        cipher = Cipher(algorithms.AES(derived_key), modes.GCM(iv, tag), backend=default_backend())
        decryptor = cipher.decryptor()
        
        # Decrypt the data
        decrypted = decryptor.update(encrypted_data) + decryptor.finalize()
        
        # Return the decrypted plaintext
        return decrypted.decode()

class AESEncryption:
    @staticmethod
    def encrypt(plaintext: str) -> str:
        iv = os.urandom(16)  # 16 bytes for AES GCM mode
        cipher = Cipher(algorithms.AES(st.session_state.aes_key), modes.GCM(iv), backend=default_backend())
        encryptor = cipher.encryptor()
        encrypted = encryptor.update(plaintext.encode()) + encryptor.finalize()
        return iv.hex() + encrypted.hex() + encryptor.tag.hex()  # Returning IV + Ciphertext + Tag

    @staticmethod
    def decrypt(encrypted_text: str) -> str:
        iv = bytes.fromhex(encrypted_text[:32])
        tag = bytes.fromhex(encrypted_text[-32:])
        encrypted_bytes = bytes.fromhex(encrypted_text[32:-32])
        cipher = Cipher(algorithms.AES(st.session_state.aes_key), modes.GCM(iv, tag), backend=default_backend())
        decryptor = cipher.decryptor()
        decrypted = decryptor.update(encrypted_bytes) + decryptor.finalize()
        return decrypted.decode()

class BlowfishEncryption:
    @staticmethod
    def encrypt(plaintext: str) -> str:
        iv = os.urandom(8)  # Blowfish block size is 8 bytes
        cipher = Cipher(algorithms.Blowfish(st.session_state.blowfish_key), modes.CBC(iv), backend=default_backend())
        encryptor = cipher.encryptor()
        padder = sym_padding.PKCS7(64).padder()
        padded_data = padder.update(plaintext.encode()) + padder.finalize()
        encrypted = encryptor.update(padded_data) + encryptor.finalize()
        return iv.hex() + encrypted.hex()

    @staticmethod
    def decrypt(encrypted_text: str) -> str:
        encrypted_bytes = bytes.fromhex(encrypted_text[16:])
        iv = bytes.fromhex(encrypted_text[:16])
        cipher = Cipher(algorithms.Blowfish(st.session_state.blowfish_key), modes.CBC(iv), backend=default_backend())
        decryptor = cipher.decryptor()
        decrypted_padded = decryptor.update(encrypted_bytes) + decryptor.finalize()
        unpadder = sym_padding.PKCS7(64).unpadder()
        decrypted = unpadder.update(decrypted_padded) + unpadder.finalize()
        return decrypted.decode()

# Function to regenerate keys
def generate_new_keys():
    st.session_state.rsa_private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    st.session_state.rsa_public_key = st.session_state.rsa_private_key.public_key()

    st.session_state.ecc_private_key = ec.generate_private_key(ec.SECP256R1())
    st.session_state.ecc_public_key = st.session_state.ecc_private_key.public_key()

    st.session_state.aes_key = os.urandom(32)  # New AES key
    st.session_state.blowfish_key = os.urandom(16)  # New Blowfish key

# Sidebar Key Management
if st.sidebar.button("Generate New Keys"):
    generate_new_keys()

# Display Key Information with Dropdown
algorithm = st.selectbox("Choose Encryption Algorithm", ["RSA", "ECC", "AES", "Blowfish"])
action = st.radio("Choose Action", ["Encrypt", "Decrypt"])

plaintext = st.text_area("Enter Text to Encrypt/Decrypt")

# Dropdown for displaying keys
show_key_option = st.selectbox("Show Key", ["No", "Yes"])

if show_key_option == "Yes":
    if algorithm == "RSA":
        st.write("RSA Public Key:")
        st.code(st.session_state.rsa_public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode())
        st.write("RSA Private Key:")
        st.code(st.session_state.rsa_private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        ).decode())
    elif algorithm == "ECC":
        st.write("ECC Public Key:")
        st.code(st.session_state.ecc_public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode())
        st.write("ECC Private Key:")
        st.code(st.session_state.ecc_private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        ).decode())
    elif algorithm == "AES":
        st.write("AES Key:")
        st.code(st.session_state.aes_key.hex())
    elif algorithm == "Blowfish":
        st.write("Blowfish Key:")
        st.code(st.session_state.blowfish_key.hex())

# Validation for Decryption (check if input is hex)
def is_hex(s):
    try:
        int(s, 16)
        return True
    except ValueError:
        return False

# Encrypt/Decrypt Button
result = None  # Ensure that result is always initialized
if st.button("Process"):
    if action == "Encrypt":
        if algorithm == "RSA":
            result = RSAEncryption.encrypt(plaintext)
        elif algorithm == "ECC":
            result = ECCEncryption.encrypt(plaintext)
        elif algorithm == "AES":
            result = AESEncryption.encrypt(plaintext)
        elif algorithm == "Blowfish":
            result = BlowfishEncryption.encrypt(plaintext)
    elif action == "Decrypt":
        if is_hex(plaintext):  # Check if input is valid hex
            if algorithm == "RSA":
                result = RSAEncryption.decrypt(plaintext)
            elif algorithm == "ECC":
                result = ECCEncryption.decrypt(plaintext)
            elif algorithm == "AES":
                result = AESEncryption.decrypt(plaintext)
            elif algorithm == "Blowfish":
                result = BlowfishEncryption.decrypt(plaintext)
        else:
            result = "Invalid hexadecimal input for decryption."

# Display Result
st.subheader("Result")
if result:
    st.write(result)
